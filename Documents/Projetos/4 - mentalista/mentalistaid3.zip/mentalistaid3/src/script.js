var numeroSecreto = parseInt(Math.random() * 101);

function chutar() {
  var resultado = document.getElementById("resultado");
  var chute = parseInt(document.getElementById("valor").value);
  console.log(chute);
  if (chute == numeroSecreto) {
    resultado.innerHTML = "Voce acertou!";
  } else if (chute > 100 || chute < 0) {
    resultado.innerHTML =
      "❕ Atenção, você deve digitar um número de 0 a 100 ❕";
  } else if (chute < numeroSecreto) {
    resultado.innerHTML = chute + " é um valor abaixo do número sorteado";
  } else if (chute > numeroSecreto) {
    resultado.innerHTML = chute + " é um valor acima do número sorteado";
  }
}
